class Book  {

    constructor(titulo, imagem, descricao, link) {
        this.titulo= titulo;
        this.imagem = imagem;
        this.descricao= descricao;
        this.link = link;
        }

}