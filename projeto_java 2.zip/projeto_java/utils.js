function Home() {
    $("#table_products").hide();
    $("#table_shelves").hide();
};

function getDataProducts() {
    $.ajax({
        url: "https://mcupacademy.herokuapp.com/api/Products",
        type: 'GET',
        contentType: 'application/json',
        success: function (data) {
            products=data;
            console.log(products);
            get_TableProducts();
        }
    });
};
function get_TableProducts() {
    for (let index = 0; index < products.length; index++) {
        $("#table_products").append(`<tr class="border border-dark">
        <td class="border border-dark"><strong>`+ index +`</strong></td>
        <td class="border border-dark"><strong>`+ products[index].discountValue +`</strong></td>
        <td class="border border-dark"><strong>`+ products[index].iva +`</strong></td>
        <td class="border border-dark"><strong>`+ products[index].pvp +`</strong></td>
        <td class="border border-dark"><strong>`+ products[index].id +`</strong></td>
      </tr>`)   
    }
};
function getDataShelves() {
    $.ajax({
        url: "https://mcupacademy.herokuapp.com/api/Shelves",
        type: 'GET',
        contentType: 'application/json',
        success: function (data) {
            shelves=data;
            console.log(shelves);
            get_TableShelves();
        }
    });
};
function get_TableShelves() {
    console.log("so nao vai para tabela")
        for (let index = 0; index < shelves.length; index++) {
            console.log(shelves);
            console.log(shelves[index]);

        $("#table_shelves").append(`<tr class="border border-dark">
        <td class="border border-dark"><strong>`+ index +`</strong></td>
        <td class="border border-dark"><strong>`+ shelves[index].capacity +`</strong></td>
        <td class="border border-dark"><strong>`+ shelves[index].rentPrice +`</strong></td>
        <td class="border border-dark"><strong>`+ shelves[index].id +`</strong></td>
        <td class="border border-dark"><strong>`+ shelves[index].productId +`</strong></td>
      </tr>`)   
    }
};
function PostProduct() {
    var discount= $("#discountValue").val();
    var IVA= $("#IVA").val();
    var pvp= $("#pvp").val();
    var Id= $("#Id").val();
    product = new Product(discount,IVA,pvp,Id);

    $.ajax({
        url: "https://mcupacademy.herokuapp.com/api/Products",
        type: 'POST',
        contentType: 'application/json',
        data:JSON.stringify(product),
        success: function (data) {
            console.log(data)
        }
    });
};
function PostShelf() {
    var capacity= $("#capacity").val();
    var rentprice= $("#rentprice").val();
    var id_shelf= $("#id_shelf").val();
    var id_product= $("#id_product").val();
    shelf = new Shelf(capacity,rentprice, id_shelf, id_product);

    $.ajax({
        url: "https://mcupacademy.herokuapp.com/api/Shelves",
        type: 'POST',
        contentType: 'application/json',
        data:JSON.stringify(shelf),
        success: function (data) {
            console.log(data)
        }
    });
};