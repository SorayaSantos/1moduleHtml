class Product  {

    constructor(discountValue,iva, pvp, id) {
        this.discountValue= discountValue;
        this.iva = iva;
        this.pvp= pvp;
        this.id = id;
        }

};
class Shelf  {

    constructor(capacity,rentprice, id_shelf, id_product) {
        this.capacity= capacity;
        this.rentprice = rentprice;
        this.id_shelf= id_shelf;
        this.id_product = id_product;
        }

};