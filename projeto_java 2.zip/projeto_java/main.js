$(document).ready(function () {
    console.log("ready!")
    $("#table_products").hide();
    $("#table_shelves").hide();
});

$("#button_products").click(function(){
    $("#table_products").show();
    getDataProducts();
});
$("#button_shelves").click(function(){
    $("#table_shelves").show();
    getDataShelves();
});
$("#home").click(function(){
    Home();
});
$("#addProduct").click(function(){
    PostProduct();
});
$("#addShelf").click(function(){
    PostShelf();
});

var products=[];
var shelves=[];