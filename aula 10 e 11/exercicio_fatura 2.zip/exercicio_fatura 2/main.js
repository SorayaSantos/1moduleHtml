$('#btn-add-artigo').click(function () {
    console.log('Ola');
    
});