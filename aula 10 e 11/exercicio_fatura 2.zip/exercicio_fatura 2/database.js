var facturas = [];

function addFacturaDB(factura){
    facturas.push(factura);
}